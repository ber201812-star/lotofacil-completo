'use strict';
const $=id=>document.getElementById(id);
let HISTORY=[],TICKETS=[];
const UNIVERSE=3268760;
const fmtDate=s=>s?new Date(s+'T12:00:00').toLocaleDateString('pt-BR'):'—';
const pad=n=>String(n).padStart(2,'0');
const randInt=n=>Math.floor(Math.random()*n);
function sortedUnique(a){return [...new Set(a)].sort((x,y)=>x-y)}
function parseNumbers(s){return (s.match(/\d+/g)||[]).map(Number)}
function validDraw(a){return a.length===15&&new Set(a).size===15&&a.every(n=>Number.isInteger(n)&&n>=1&&n<=25)}
function rng(seed){let x=seed>>>0;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return(x>>>0)/4294967296}}
function shuffle(a,r=Math.random){for(let i=a.length-1;i>0;i--){let j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function randomTicket(r=Math.random){return shuffle(Array.from({length:25},(_,i)=>i+1),r).slice(0,15).sort((a,b)=>a-b)}
function overlap(a,b){const s=new Set(a);return b.reduce((n,x)=>n+s.has(x),0)}
function frequency(history){let f=Array(26).fill(0);for(const d of history)for(const n of d.dezenas)f[n]++;return f}
function makeWeightedTicket(history,windowSize,r=Math.random){
 const hist=history.slice(-windowSize),f=frequency(hist),expected=Math.max(1,hist.length*.6);
 const pool=Array.from({length:25},(_,i)=>i+1),out=[];
 while(out.length<15){let weights=pool.map(n=>Math.max(.15,f[n]/expected)**.65),total=weights.reduce((a,b)=>a+b,0),x=r()*total,idx=0;for(;idx<weights.length-1;idx++){x-=weights[idx];if(x<=0)break}out.push(pool.splice(idx,1)[0])}
 return out.sort((a,b)=>a-b)
}
function scoreStructure(t){let even=t.filter(n=>n%2===0).length,sum=t.reduce((a,b)=>a+b,0),rows=Array(5).fill(0),cols=Array(5).fill(0);for(const n of t){rows[Math.floor((n-1)/5)]++;cols[(n-1)%5]++}return -Math.abs(even-7.5)*1.0-Math.abs(sum-195)*.025-rows.reduce((s,x)=>s+Math.max(0,x-4)*1.2,0)-cols.reduce((s,x)=>s+Math.max(0,x-4)*1.2,0)}
function generateGames(){
 if(!HISTORY.length){alert('O histórico não foi carregado.');return}
 const k=Math.max(1,Math.min(100,Number($('qty').value)||1));$('qty').value=k;
 const strategy=$('strategy').value,windowVal=$('window').value,windowSize=windowVal==='all'?HISTORY.length:Number(windowVal),maxOverlap=Number($('overlap').value);
 const seed=(Date.now()^HISTORY.length*2654435761^k*2246822519)>>>0,r=rng(seed);
 const pool=new Map(),attempts=Math.min(7000,Math.max(800,k*70));
 const histWindow=HISTORY.slice(-windowSize),freqs=frequency(histWindow);
 const ticketScore=t=>t.reduce((s,n)=>s+freqs[n],0)+scoreStructure(t);
 for(let i=0;i<attempts;i++){let t;if(strategy==='random')t=randomTicket(r);else if(strategy==='frequency')t=makeWeightedTicket(HISTORY,windowSize,r);else t=r()<.5?makeWeightedTicket(HISTORY,windowSize,r):randomTicket(r);pool.set(t.join('-'),t)}
 let candidates=[...pool.values()];
 if(strategy!=='random')candidates.sort((a,b)=>ticketScore(b)-ticketScore(a));
 const selected=[];
 for(const t of candidates){if(selected.length>=k)break;if(selected.every(x=>overlap(x,t)<=maxOverlap))selected.push(t)}
 // If diversity threshold is too restrictive for the requested count, fill remaining places with unique valid tickets.
 let guard=0;while(selected.length<k&&guard++<k*300){let t=strategy==='random'?randomTicket(r):makeWeightedTicket(HISTORY,windowSize,r);if(!selected.some(x=>x.join('-')===t.join('-'))&&selected.every(x=>overlap(x,t)<=maxOverlap))selected.push(t)}
 TICKETS=selected;renderTickets();$('genSummary').textContent=`${TICKETS.length} jogo(s) gerado(s). Estratégia: ${strategy==='random'?'aleatória uniforme':strategy==='frequency'?'frequência histórica experimental':'equilibrada'}. Cada jogo tem 15 dezenas distintas.`;
}
function renderTickets(hits=null){
 const root=$('tickets');root.innerHTML='';
 TICKETS.forEach((t,i)=>{const card=document.createElement('article');card.className='ticket';const hitSet=hits?new Set(hits):null;card.innerHTML=`<div class="ticket-head"><span>Jogo ${i+1}</span><span>${t.reduce((s,n)=>s+n,0)} pontos de soma</span></div><div class="balls">${t.map(n=>`<span class="ball ${hitSet&&hitSet.has(n)?'hit':''}">${pad(n)}</span>`).join('')}</div><div class="ticket-meta">${t.filter(n=>n%2===0).length} pares · ${15-t.filter(n=>n%2===0).length} ímpares</div>`;root.appendChild(card)})
}
function statsRender(){
 const n=HISTORY.length,latest=HISTORY[HISTORY.length-1],f=frequency(HISTORY),max=Math.max(...f.slice(1));
 $('statCards').innerHTML=[['Concursos',n.toLocaleString('pt-BR')],['Primeiro concurso',HISTORY.length?HISTORY[0].concurso:'—'],['Último concurso',latest?latest.concurso:'—'],['Dezenas por sorteio','15 de 25']].map(([a,b])=>`<div class="card"><div class="muted">${a}</div><div class="metric">${b}</div></div>`).join('');
 $('frequency').innerHTML=Array.from({length:25},(_,i)=>i+1).map(n=>`<div class="barrow"><b>${pad(n)}</b><div class="bartrack"><div class="barfill" style="width:${100*f[n]/max}%"></div></div><span>${f[n]}</span></div>`).join('');
 $('latest').innerHTML=latest?`<p><b>Concurso ${latest.concurso}</b> · ${fmtDate(latest.data)}</p><div class="draw-balls">${latest.dezenas.map(n=>`<span class="ball">${pad(n)}</span>`).join('')}</div>`:'Sem dados';
 const evens=HISTORY.reduce((s,d)=>s+d.dezenas.filter(n=>n%2===0).length,0),avg= n?evens/n:0;
 $('parity').innerHTML=`<p>Média de dezenas pares por sorteio: <b>${avg.toFixed(2).replace('.',',')}</b></p><p class="muted">A média esperada teoricamente é 7,5 pares por concurso.</p>`;
}
function showCheck(){
 const a=parseNumbers($('drawInput').value);
 if(!validDraw(a)){alert('Informe exatamente 15 dezenas distintas, entre 1 e 25.');return}
 if(!TICKETS.length){alert('Gere ou carregue jogos antes de conferir.');return}
 const draw=sortedUnique(a),contest=$('drawContest').value;
 $('checkResults').innerHTML=`<div class="card"><b>${contest?`Concurso ${contest} · `:''}Resultado conferido</b><div class="draw-balls">${draw.map(n=>`<span class="ball">${pad(n)}</span>`).join('')}</div></div>`+TICKETS.map((t,i)=>{const hits=overlap(t,draw);return `<div class="result-row"><span>Jogo ${i+1}</span><span class="hit-count">${hits} acertos</span><span class="muted">${hits>=11?'Faixa de premiação teórica':'Sem faixa de premiação'}</span></div>`}).join('');
 renderTickets(draw);
}
function loadContest(){
 const n=Number($('loadContest').value),d=HISTORY.find(x=>x.concurso===n);
 if(!d){alert('Concurso não encontrado na base local. Atualize o histórico ou confira o número.');return}
 $('drawInput').value=d.dezenas.map(pad).join(' ');$('drawContest').value=d.concurso;
}
async function refreshHistory(){
 const b=$('refresh');b.disabled=true;b.textContent='Atualizando…';
 try{
  const current=HISTORY.length?HISTORY[HISTORY.length-1].concurso:0;
  // API oficial da CAIXA. Se CORS ou rede impedir a leitura, mantemos a base local intacta.
  let latest;
  const resp=await fetch('https://servicebus2.caixa.gov.br/portaldeloterias/api/lotofacil',{cache:'no-store'});
  if(!resp.ok)throw new Error('API indisponível');latest=await resp.json();
  const last=Number(latest.numero||latest.numeroConcurso||latest.concurso);
  if(!last)throw new Error('Resposta da API sem número de concurso');
  const known=new Map(HISTORY.map(d=>[d.concurso,d]));
  for(let c=Math.max(1,current+1);c<=last;c++){
   try{const rr=await fetch(`https://servicebus2.caixa.gov.br/portaldeloterias/api/lotofacil/${c}`,{cache:'no-store'});if(!rr.ok)continue;const x=await rr.json();const nums=(x.listaDezenas||x.dezenas||[]).map(Number).sort((a,b)=>a-b);if(nums.length===15&&nums.every(n=>n>=1&&n<=25))known.set(c,{concurso:c,data:normalizeDate(x.dataApuracao||x.dataSorteio),dezenas:nums})}catch(e){}
  }
  const merged=[...known.values()].sort((a,b)=>a.concurso-b.concurso);if(merged.length===HISTORY.length&&last<=current)throw new Error('Histórico já parece atualizado');
  HISTORY=merged;localStorage.setItem('lf-history-cache',JSON.stringify(HISTORY));updateStatus();statsRender();alert(`Histórico local atualizado até o concurso ${HISTORY[HISTORY.length-1].concurso}. Para guardar a base no projeto, exporte/baixe o histórico atualizado no seu repositório.`);
 }catch(e){alert('Não foi possível atualizar automaticamente neste navegador. Isso pode ocorrer por bloqueio de CORS, conexão ou indisponibilidade da API. A base local foi preservada. Detalhe: '+e.message)}
 finally{b.disabled=false;b.textContent='Atualizar histórico'}
}
function normalizeDate(s){if(!s)return '';if(/^\d{4}-\d\d-\d\d$/.test(s))return s;const m=String(s).match(/^(\d{2})\/(\d{2})\/(\d{4})$/);return m?`${m[3]}-${m[2]}-${m[1]}`:s}
function updateStatus(){const d=HISTORY[HISTORY.length-1];$('dataStatus').textContent=d?`${HISTORY.length.toLocaleString('pt-BR')} concursos · até ${d.concurso} (${fmtDate(d.data)})`:'Histórico não carregado'}
function copyTickets(){if(!TICKETS.length){alert('Gere os jogos primeiro.');return}const txt=TICKETS.map((t,i)=>`Jogo ${i+1}: ${t.map(pad).join(' ')}`).join('\n');navigator.clipboard?.writeText(txt).then(()=>alert('Jogos copiados.')).catch(()=>prompt('Copie os jogos:',txt))}
function exportCSV(){if(!TICKETS.length){alert('Gere os jogos primeiro.');return}const rows=['Jogo,Dezenas,Soma,Pares',...TICKETS.map((t,i)=>`${i+1},"${t.map(pad).join(' ')}",${t.reduce((a,b)=>a+b,0)},${t.filter(n=>n%2===0).length}`)];const blob=new Blob(['\ufeff'+rows.join('\n')],{type:'text/csv;charset=utf-8;'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='jogos_lotofacil.csv';a.click();URL.revokeObjectURL(a.href)}
async function backtest(){
 const btn=$('backtest');btn.disabled=true;btn.textContent='Testando…';$('btResult').innerHTML='';
 try{
  const n=Number($('btN').value),k=Number($('btK').value),start=Math.max(200,HISTORY.length-n),results=[];
  if(HISTORY.length<start+1||start<20)throw new Error('Histórico insuficiente para esse teste.');
  // Reproducible walk-forward: at each target draw only earlier contests are used.
  for(let i=start;i<HISTORY.length;i++){
   const past=HISTORY.slice(0,i),target=HISTORY[i].dezenas,seed=(i*7919+1777)>>>0,r=rng(seed);
   let modelBest=0,randomBest=0,model11=0,random11=0;
   for(let j=0;j<k;j++){
    const model=makeWeightedTicket(past,Math.min(200,past.length),r),rnd=randomTicket(r);
    const hm=overlap(model,target),hr=overlap(rnd,target);
    modelBest=Math.max(modelBest,hm);randomBest=Math.max(randomBest,hr);
    if(hm>=11)model11++;if(hr>=11)random11++;
   }
   results.push({modelBest,randomBest,model11,random11});
   if((i-start)%10===0)await new Promise(resolve=>setTimeout(resolve,0));
  }
  const count=results.length,avgM=results.reduce((s,x)=>s+x.modelBest,0)/count,avgR=results.reduce((s,x)=>s+x.randomBest,0)/count,atleastM=results.reduce((s,x)=>s+x.model11,0),atleastR=results.reduce((s,x)=>s+x.random11,0);
  $('btResult').innerHTML=`<div class="cards spaced"><div class="card"><div class="muted">Concursos testados</div><div class="metric">${count}</div></div><div class="card"><div class="muted">Média melhor jogo · modelo</div><div class="metric">${avgM.toFixed(2).replace('.',',')}</div></div><div class="card"><div class="muted">Média melhor jogo · aleatório</div><div class="metric">${avgR.toFixed(2).replace('.',',')}</div></div><div class="card"><div class="muted">Jogos com ≥11 acertos</div><div class="metric">${atleastM} / ${atleastR}</div></div></div><p>Comparação feita em ${count} concursos finais, com ${k} jogo(s) por concurso. A métrica “melhor jogo” é o maior número de acertos entre os jogos daquele concurso. Resultados passados não demonstram vantagem futura; diferenças pequenas podem ser mero acaso.</p>`;
 }catch(e){$('btResult').textContent=e.message}finally{btn.disabled=false;btn.textContent='Executar teste'}
}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.panel').forEach(x=>x.classList.toggle('active',x.id===b.dataset.tab))}));
$('generate').addEventListener('click',generateGames);$('check').addEventListener('click',showCheck);$('loadDraw').addEventListener('click',loadContest);$('refresh').addEventListener('click',refreshHistory);$('copy').addEventListener('click',copyTickets);$('csv').addEventListener('click',exportCSV);$('clear').addEventListener('click',()=>{TICKETS=[];$('tickets').innerHTML='';$('genSummary').textContent='';$('checkResults').innerHTML=''});$('backtest').addEventListener('click',backtest);
async function init(){
 try{const cache=localStorage.getItem('lf-history-cache');if(cache){const a=JSON.parse(cache);if(Array.isArray(a)&&a.length)HISTORY=a}
 if(!HISTORY.length){const r=await fetch('data/history.json');if(!r.ok)throw new Error('arquivo de histórico não encontrado');HISTORY=await r.json()}
 HISTORY=HISTORY.filter(d=>Number.isInteger(d.concurso)&&validDraw(d.dezenas)).sort((a,b)=>a.concurso-b.concurso);
 updateStatus();statsRender();
 }catch(e){$('dataStatus').textContent='Erro ao carregar histórico';$('genSummary').textContent='Abra o app por um servidor web (ex.: GitHub Pages) para que o navegador possa ler data/history.json. O arquivo não carrega corretamente via file:// em alguns navegadores.'}
}
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
init();
